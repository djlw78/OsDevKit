#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

extern "C"

void kmain() {
  
}