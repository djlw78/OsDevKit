#include <system.h>


 
uint8_t make_color(enum Colors fg, enum Colors bg) 
{
    return fg | bg << 4;
}
 
uint16_t make_vgaentry(char c, uint8_t color) 
{
    uint16_t c16 = c;
    uint16_t color16 = color;
    return c16 | color16 << 8;
}
 
size_t strlen(const char* str) 
{
    size_t ret = 0;
    while ( str[ret] != 0 )
        ret++;
    return ret;
}
 
static const size_t VGA_WIDTH = 80;
static const size_t VGA_HEIGHT = 25;
 
size_t console_row = 0;
size_t console_column = 0;
uint8_t console_color = ColorWhite;
uint16_t* console_buffer  = (uint16_t*) 0xB8000;
 

void console_setcolor(uint8_t color) 
{
    console_color = color;
}
 
void console_putentryat(char c, uint8_t color, size_t x, size_t y) 
{
    const size_t index = y * VGA_WIDTH + x;
    console_buffer[index] = make_vgaentry(c, color);
}
 
void Console_Write_Char(char c) 
{
    if(c == '\n')
    {
        console_column = 0;
        console_row++;
    }
    else
    {
    console_putentryat(c, console_color, console_column, console_row);
    }
    if (++console_column == VGA_WIDTH) 
    {
        console_column = 0;
        if (++console_row == VGA_HEIGHT) 
        {
            console_row = 0;
        }
    }
}
 
void Console_Write_String(const char* data) 
{
    size_t datalen = strlen(data);
    for (size_t i = 0; i < datalen; i++)
        Console_Write_Char(data[i]);
}
    
void Console_Clear()
{
    for (size_t y = 0; y < VGA_HEIGHT; y++) 
    {
        for (size_t x = 0; x < VGA_WIDTH; x++) 
        {
            const size_t index = y * VGA_WIDTH + x;
            console_buffer[index] = make_vgaentry(' ', console_color);
        }
    }
}

void Console_Write_Char_Colored(char c, uint8_t color)
{
    console_setcolor(color);
    Console_Write_Char(c);
    console_setcolor(ColorWhite);
}

void Console_Write_String_Colored(const char* data, uint8_t color)
{
    console_setcolor(color);
    Console_Write_String(data);
    console_setcolor(ColorWhite);
}
    