#include <system.h>

extern "C"

void kmain() 
{
    Console_Clear();
    Print_Info("Starting boot sequence");
}

void Print_Info(const char* txt)
{
    Console_Write_String("[");
    Console_Write_String_Colored("Info", ColorGreen);
    Console_Write_String("]");
    Console_Write_String(txt);
    Console_Write_String("\n");
}

void Print_Error(const char* txt)
{
    Console_Write_String("[");
    Console_Write_String_Colored("Error", ColorRed);
    Console_Write_String("]");
    Console_Write_String(txt);
    Console_Write_String("\n");
}